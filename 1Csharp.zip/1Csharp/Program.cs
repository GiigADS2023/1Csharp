﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1Csharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Somar os números inseridos
            int somaNumeros = 0;

            //Par & ímpar
            int Par = 0;
            int Impar = 0;

            /*1 - Solicitar a inserção de 5 números, ao final, imprimir os números pares, 
             * números ímpares e a média geral desses números.*/
            for (int i = 1; i <= 5; i++)
            {
                //Inserção de 5 números
                Console.WriteLine("Digite o " + i + "º número");
                int numeros = int.Parse(Console.ReadLine());
                somaNumeros += numeros;

                //Mostrar quais são pares e quais são ímpares
                if (numeros % 2 == 0)
                {
                    Par++;
                } else
                {
                    Impar++;
                }

            }

                //Mostrar os números pares e ímpares
                Console.WriteLine("Números pares são: " + Par);
                Console.WriteLine("Números ímpares são: " + Impar);

                //Média de pares e ímpares
                double mediaNumeros = somaNumeros / 5;
                Console.WriteLine("A média dos numeros ficou: " + mediaNumeros);
                Console.ReadLine();

        }
    }
}
